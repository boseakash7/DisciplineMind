class ApiUrl {
  /// Broker apps list for blocking / GTT behaviour (GET, JSON).
  static const String tradingApps = 'trading-apps';

  /// DMT levels for Trades tab dropdown (GET, JSON).
  static const String dmtLevels = 'dmt-levels';

  /// Hit trades for selected level (POST form: user_id, level_id).
  static const String dmtLevelUserHitTrades = 'dmt-level/user-hit-trades';

  /// DMT score history for Analysis tab (POST form: user_id).
  static const String dmtScoreHistory = 'dmt-score/history';

  /// User return percentages for Analysis tab (POST form: user_id, level_id).
  static const String dmtLevelUserReturnPercentages =
      'dmt-level/user-return-percentages';

  /// User levels summary for BM tab (POST form: user_id).
  static const String dmtLevelUserLevelsSummary =
      'dmt-level/user-levels-summary';

  static String loginUrl = "user/login";
  static String sendOtpUrl = "user/send-otp";
  static String verifyOtpUrl = "user/verify-otp";
  static String searchInstrument = "instrument/search";
  static String getAlertsByUser = "alert/get-by-user-id";

  /// API to check if trading apps should stay blocked. Returns { "should_block": true/false }.
  /// Backend can use alerts or any logic. If endpoint missing, app falls back to getAlertsByUser.
  static String shouldBlockApps = "alert/should-block-apps";
  static String deleteAlert = "alert/delete";
  static String createAlertUrl = "alert/create";
  static String signUpUrl = "user/register";
  static String quoteUrl = "instrument/quote";

  static const String fcmSync = "fcm/sync";

  static const String getMessagesByUser = "messages/get-by-user";
  static const String gttAlertCreate = "gtt/alert/create";

  /// Confirms user deleted the trade in the broker app (form: trade_id, user_id).
  static const String deleteTrade = "delete/trade";

  /// Confirms user trailed the SL in the broker app (form: trade_id, user_id).
  static const String editTrade = "edit/trade";

  /// Confirms user updated the GTT in the broker app (form: trade_id, user_id, new_entry).
  static const String editGtt = "edit/gtt";

  /// Confirms target hit (form: trade_id, user_id, hit_price).
  static const String tradeExecuted = "trade/executed";

  /// Confirms GTT was missed (form: user_id, trade_id).
  static const String gttMissed = "trade/gtt-missed";

  /// Set up trading process (form: user_id, trading_segment, instrument, trading_capital, trades_per_day, max_risk_percent, market_entry_time, broking_app, permission_overlay_enabled, permission_usage_stats_enabled, terms_accepted).
  static const String processSetup = "process/setup";

  /// Fetch user process details (form: user_id).
  static const String processFetch = "process/fetch";

  /// Edit/update existing process (form: user_id, process_id, trading_segment, instrument, trading_capital, trades_per_day, max_risk_percent, market_entry_time, broking_app, permission_overlay_enabled, permission_usage_stats_enabled, terms_accepted).
  static const String processEdit = "process/edit";

  /// Endpoint to fetch dynamic app config keys (GET, JSON).
  static const String configKeys = "config/keys";

  /// Endpoint to send user query to LLM AI (POST JSON: user_id, user_query).
  static const String llmAsk = "llm/ask";

  /// Activate Mind Control (POST form: user_id, is_mind_controll_active).
  static const String mindControlActive = "user/mind-control-active";
}
