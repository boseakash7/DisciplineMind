import 'package:discipline_mind/common/common.dart';
import 'package:discipline_mind/model/dmt_level_model.dart';
import 'package:discipline_mind/model/dmt_user_hit_trades_model.dart';
import 'package:discipline_mind/services/api/api_services.dart';
import 'package:discipline_mind/services/api/api_url.dart';
import 'package:get/get.dart';

/// Loads DMT levels and user hit-trades for the Trades tab.
class DmtLevelsService extends GetxService {
  final RxList<DmtLevel> levels = <DmtLevel>[].obs;
  final Rxn<DmtLevel> selectedLevel = Rxn<DmtLevel>();
  final Rxn<DmtUserHitTradesPayload> hitTrades = Rxn<DmtUserHitTradesPayload>();

  final RxBool isLoadingLevels = false.obs;
  final RxBool isLoadingTrades = false.obs;
  final RxnString levelsError = RxnString();
  final RxnString tradesError = RxnString();

  bool _levelsRefreshInFlight = false;

  /// Overview stats — API values with 0/empty fallbacks when response not loaded.
  int get displayTotalTrades {
    final payload = hitTrades.value;
    if (payload != null) return payload.totalTrades;
    return 0;
  }

  int get displayTotalWins {
    final payload = hitTrades.value;
    if (payload != null) return payload.totalWins;
    return 0;
  }

  /// From API `trade_accuracy_text` / `trade_accuracy`, else computed, else 0%.
  String get displayTradeAccuracy {
    final payload = hitTrades.value;
    if (payload != null) {
      final accuracy = payload.displayTradeAccuracy;
      if (accuracy.isNotEmpty) return accuracy;
      return '0%';
    }
    return '0%';
  }

  /// 0–100 for the accuracy ring animation.
  double get displayTradeAccuracyPercent {
    final payload = hitTrades.value;
    if (payload != null) {
      return payload.tradeAccuracyPercentValue ?? 0;
    }
    return 0;
  }

  String get displayMyAverageReturn {
    final payload = hitTrades.value;
    if (payload != null && payload.totalAverageReturnPercentage != null) {
      final val = double.tryParse(payload.totalAverageReturnPercentage.toString());
      if (val != null) return '${val.toStringAsFixed(2)}%';
      return '${payload.totalAverageReturnPercentage}%';
    }
    return '0.00%';
  }

  String get displayMctAverageReturn {
    final payload = hitTrades.value;
    if (payload != null && payload.totalMctAverageReturnPercentage != null) {
      final val = double.tryParse(payload.totalMctAverageReturnPercentage.toString());
      if (val != null) return '${val.toStringAsFixed(2)}%';
      return '${payload.totalMctAverageReturnPercentage}%';
    }
    return '0.00%';
  }

  String get displayFrr => displayMyAverageReturn;
  String get displayRtt => displayMctAverageReturn;

  List<DmtHitTrade> get displayTrades {
    final trades = hitTrades.value?.trades ?? const <DmtHitTrade>[];
    return trades
        .where((t) {
          final s = t.status.toLowerCase().trim();
          return s == 'completed' || s.endsWith('completed') || s.contains('completed') || s.isEmpty;
        })
        .toList();
  }

  /// True after a successful `user-hit-trades` response (including empty `trades`).
  bool get hasLoadedHitTrades => hitTrades.value != null;

  int _fetchSequence = 0;

  @override
  void onInit() {
    super.onInit();
    ever(selectedLevel, (DmtLevel? level) {
      if (level != null) {
        fetchUserHitTrades(level.id);
      }
    });
  }

  DmtLevel? levelById(int id) {
    for (final level in levels) {
      if (level.id == id) return level;
    }
    return null;
  }

  void selectById(int? id) {
    if (id == null) return;
    if (selectedLevel.value?.id == id) return;
    final level = levelById(id);
    if (level != null) {
      selectedLevel.value = level;
    }
  }

  void selectLevel(DmtLevel level) {
    if (selectedLevel.value?.id == level.id) return;
    selectedLevel.value = level;
  }

  Future<bool> refreshLevels() async {
    if (_levelsRefreshInFlight) return levels.isNotEmpty;
    _levelsRefreshInFlight = true;
    isLoadingLevels.value = true;
    levelsError.value = null;

    try {
      final api = _api();
      final response = await api.get(ApiUrl.dmtLevels);

      if (!response.isSuccess || response.data is! Map) {
        levelsError.value =
            response.errorMessage ?? 'Could not load DMT levels';
        return false;
      }

      final parsed = DmtLevelsResponse.fromJson(
        Map<String, dynamic>.from(response.data as Map),
      );

      if (!parsed.isOk && parsed.payload.isEmpty) {
        levelsError.value = 'No DMT levels available';
        return false;
      }

      final valid = parsed.payload.where((l) => l.isValid).toList();
      levels.assignAll(valid);
      _ensureLevelSelection();
      return levels.isNotEmpty;
    } catch (e) {
      levelsError.value = e.toString();
      return false;
    } finally {
      isLoadingLevels.value = false;
      _levelsRefreshInFlight = false;
    }
  }

  Future<bool> fetchUserHitTrades(int levelId, {bool force = false}) async {
    final userId = Common.userData.value?.payload?.id?.toString();
    if (userId == null || userId.isEmpty) {
      tradesError.value = 'Please log in to view trades';
      return false;
    }

    final currentToken = ++_fetchSequence;
    isLoadingTrades.value = true;
    tradesError.value = null;

    try {
      final response = await _api().postFormData(ApiUrl.dmtLevelUserHitTrades, {
        'user_id': userId,
        'level_id': levelId.toString(),
      });

      // If a newer request was dispatched while this was in-flight, discard this result.
      if (currentToken != _fetchSequence || selectedLevel.value?.id != levelId) {
        return false;
      }

      if (!response.isSuccess || response.data is! Map) {
        tradesError.value =
            response.errorMessage ?? 'Could not load trade details';
        hitTrades.value = null;
        return false;
      }

      final parsed = DmtUserHitTradesResponse.fromJson(
        Map<String, dynamic>.from(response.data as Map),
      );

      if (parsed.payload == null) {
        tradesError.value = 'No trade data for this level';
        hitTrades.value = null;
        return false;
      }

      hitTrades.value = parsed.payload;
      return true;
    } catch (e) {
      if (currentToken == _fetchSequence) {
        tradesError.value = e.toString();
        hitTrades.value = null;
      }
      return false;
    } finally {
      if (currentToken == _fetchSequence) {
        isLoadingTrades.value = false;
      }
    }
  }

  void _ensureLevelSelection() {
    if (levels.isEmpty) {
      selectedLevel.value = null;
      return;
    }
    final current = selectedLevel.value;
    if (current != null && levelById(current.id) != null) return;
    selectedLevel.value = levels.first;
  }

  Future<void> ensureLoaded() async {
    if (levels.isEmpty) {
      await refreshLevels();
    } else if (selectedLevel.value != null) {
      await fetchUserHitTrades(selectedLevel.value!.id);
    }
  }

  /// Reload levels and hit-trades for the current selection (e.g. Trades tab focused).
  Future<void> refreshTabData() async {
    await refreshLevels();
    final level = selectedLevel.value;
    if (level != null) {
      await fetchUserHitTrades(level.id, force: true);
    }
  }

  /// Backward-compatible alias for level list refresh.
  Future<bool> refresh() => refreshLevels();

  ApiService _api() {
    return Get.isRegistered<ApiService>()
        ? Get.find<ApiService>()
        : Get.put(ApiService(), permanent: true);
  }
}
